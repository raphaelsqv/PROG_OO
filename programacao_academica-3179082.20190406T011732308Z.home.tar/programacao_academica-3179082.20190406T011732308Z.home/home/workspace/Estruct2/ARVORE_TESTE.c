#include <stdlib.h>
#include <stdio.h>

///////////// STRUCT ARVORE ///////////
struct arv {
   char info;
   struct arv* esq;
   struct arv* dir;
};
typedef struct arv Arv;
 ///////////// FIM STRUCT ARVORE //////////////
////-----------------------------------------------------////
/*    Lista de FUNCOES          */

///// CRIAR ARVORE ////

Arv* arv_criavazia(void)
{
 return NULL;
}
///// FIM CRIA ARVORE /////

//------------------------------------------------------------//
/* Verificador ARVORE VAZIA
 ---> INDICA SE A ARVORE ESTA VAZIA */

int arv_vazia(Arv* a)
{
return a==NULL;
}

///// FIM AROVRE VAZIA /////
//----------------------------------------------------------//
///  ARVORE CRIA ///
Arv* arv_cria(char c, Arv* sae, Arv* sad){
 
Arv* p=(Arv*)malloc(sizeof(Arv));
p->info = c;
p->esq = sae;
p->dir = sad;
return p;
}
/// FIM ARVORE CRIA /////
//---------------------------------------------------------//
////// ARVORE IMRPRIME /////
void arv_imprime(Arv* a)
{
if (!arv_vazia(a)){
printf("%c ",a->info); /* mostra raiz */

arv_imprime(a->esq); /* mostra sae */
arv_imprime(a->dir); /* mostra sad */
}
}
//// FIM ARVORE IMRPRIME /////
//--------------------------------------------------------//
/// Arvore Libera /////

Arv* arv_libera(Arv* a){

if (!arv_vazia(a)){
arv_libera(a->esq); /* libera sae */
arv_libera(a->dir); /* libera sad */
free(a); /* libera raiz */
}
return NULL;
}

///// FIM ARVORE LIBERA /////

// FUNCAO SIMETRICA //
void simetrica(Arv *a) {
    if(!arv_vazia(a))  {
        simetrica(a -> esq);
        printf("%c ",a -> info);
        simetrica(a->dir); 
    }
}
// FIM SIMETRICA ///
//--------------------------------------------------------//

// FUNCAO PRE_ORDEM ///

void preOrdem(Arv *a){
     if(!arv_vazia(a)){
      printf("%c ", a -> info);
      preOrdem(a -> esq);
      preOrdem(a -> dir);
     } 
}

// FIM PRE ORDEM ////

/// FUNCAO POS ORDEM ////


void posOrdem(Arv *a) {
     if(!arv_vazia(a)){
      posOrdem(a -> esq);
      posOrdem(a -> dir);
      printf("%c " , a-> info );
     }
}
//// FIM POS ORDEM ////////

//---------------------------------------------------------//


int arv_pertence (Arv* a, char c) {
 
 if (arv_vazia(a))
return 0; /* árvore vazia: não encontrou */
else
return a->info==c ||
arv_pertence(a->esq,c) ||
arv_pertence(a->dir,c);

}



//--------------------------------------//
// FIM FUNCOES//


//--------------------- PRINCIPAL -----------------------//
 int main(){

 //// Criacao da ARVORE /////
  Arv* a1= arv_cria('D' ,arv_criavazia(),arv_criavazia());
  /* sub-arvore 'b' */
  Arv* a2= arv_cria('B' ,arv_criavazia(),a1);
  /* sub-arvore 'e' */
  Arv* a3= arv_cria('E', arv_criavazia(),arv_criavazia());
  /* sub-arvore 'f' */
  Arv* a4= arv_cria('F' ,arv_criavazia(),arv_criavazia());
  /* sub-arvore 'c' */
  Arv* a5= arv_cria('C' ,a3,a4 );
  /*  'a' */
  Arv* a = arv_cria('A' ,a2,a5 );
   
  //// IMPRIMIR ARVORE //////
  printf("Simetria\n");
  simetrica(a);
  printf("\n\nPre Ordem\n");
  
  preOrdem(a);
  printf("\n\nPos Ordem\n");
  
  posOrdem(a);
  printf("\n");
  
  char proc = 'D';
  if(arv_pertence(a,proc)) 
    printf("\n \n A informacao %c pertence a arvore!\n",proc);
    
  else 
  printf(" \n \n A informacao %c nao pertence a arvore!\n ", proc);
  
  arv_libera(a);
  system("pause");
  
  int folhas(Arv* a)
  {
   if(arv_vazia(a->esq)&& arv_vazia(a->dir)) return 1;
   
   else if(!arv_vazia(a->esq)&& arv_vazia(a->dir)) return folhas(a->esq);
   
     else if(arv_vazia(a->esq)&& !arv_vazia(a->dir)) return folhas(a->dir);
     
      return folhas(a->esq)+folhas(a->dir);
  }
  
  
  return 0 ;
  
  }