#include<stdlib.h>
#include<stdio.h>


///////////// STRUCT ARVORE ///////////
struct arv {
   char info;
   struct arv* esq;
   struct arv* dir;
};
typedef struct arv Arv;
 ///////////// FIM STRUCT ARVORE //////////////

////-----------------------------------------------------////
/*    Lista de FUNCOES          */



/* ============= FUNCAO BUSCA ==============*/
abb_busca (Arv* r , int v )
{
    if (r == NULL) return NULL;
    else if (r->info > v ) return abb_busca(r->esq, v);
    else if (r->infor < v) return abb_busca(r->dir,v);
    else return r;
}
/*======= FIM FUNCAO BUSCA ====================  */




void showmenor(Arv* a, int x) {
 if(a == NULL)
 return;
 showmenor(a-> esq,x);
 if (a-> info < x) {
     print ("%3d" , a-> info);
     showmenor(a-> dir , x);
 }

}


/* ==========FUNCAO PROCURA O MENOR VALOR DA ARVORE ========= */ 

Arv* menor (Arv* a) {
    
    if (a == NULL) return NULL;
    while (a-> esq !=NULL)
    a=a-> esq;
        return a;
/* ==========FIM PROCURA O MENOR VALOR DA ARVORE ========= */
///////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////




Arv* busca_no(Arv* a)
{
 if(a == NULL) return NULL;
 Arv* f = a -> esq;
 if (f == NULL) return NULL;
 while (f -> dir != NULL)
  f = f -> dir;
  return f;
}

void imprime_crescente(Arv *a) {
    
    if (!arv_vazia(a)) {
        imprime_crescente(a -> esq);
        printf("%3d", a->info);
        imprime_crescente(a->dir);
          }
} 
 
 
/////* ------ FIM FUNCOES -------- */////////////////////// 
 
/////*----PROGRAMA PRINCIPAL ABAIXO----*/////////////////////
 
 int main(){
 
 Arv* a;
 
 a = arv_criavazia();

 
 /* Vai inserir , recursivamente , valores na árvore */
 
 a = abb_insere (a,6);
 a = abb_insere (a,2);
 a = abb_insere (a,8);
 a = abb_insere (a,1);
 a = abb_insere (a,4);
 a = abb_insere (a,3);
 
 ////////////////////////////////////////////////////////////////////////////
 /* vai imprimir , recursivamente , todos os elementos em ordem crescente */
 
 imprime_crescente(a);
 printf("\n");
 
 
 /*-----///////////////////////////////////////////////////////////------*/
 /* vai buscar , recursivamente , um valor na árvore */
 
 Arv*k = abb_busca(a,1);
 
 inf (k! = NULL) printf("info = %d \n", k-> info);
 printf("\n");
 
 //////////////////////////////////////////////////////////////////////////////////////////////
 /* imprime , recursivamente todos os valores nos nós da árvore a que sejam menores que x ,
 
 em ordem crescente . */
 
 showmenor(a,5);
 printf("\n");
 
 /////////////////////////////////////////////////////////////////////////
//// /* Encontra iterativamente , um ponteiro para o menor valor da árvore */
 
 k = menor(a);
 if(k! = NULL) printf("A menor informacao = %d \n" , k_> info);
 
 
 /* Encontra iterativamente , o valor que antecede a raiz */
 
 print("/n");
 
 k= busca_no(a);
 if(k! = NULL) printf ("Valor que antecede a raiaz = %d \n", k -> info);
    else
     printf ("NAO ha VALOR");
     
    arv_libera(a);
    system("pause");
    return 0;
  
 
 
 
 
 