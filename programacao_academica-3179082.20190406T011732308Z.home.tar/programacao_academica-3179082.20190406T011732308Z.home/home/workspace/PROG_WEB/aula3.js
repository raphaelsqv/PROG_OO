//function
function somar(x,y){
      document.write("<br>soma de x e y é:\u00a0"+(x+y));
}

somar(10,30);

// passando os valores pelo prompt
function somar(x,y){
document.write("<br>soma de x e y é:\u00a0" +(x+y));
}

var x=parseInt(prompt("Entre com o valor de X para soma:\u00a0"));
var y=parseInt(prompt("Entre com o valor de Y:para soma\u00a0"));
somar(x,y);
// Subtração
function sub(a,b){
	document.write("<br>subtrair de A e B é:\u00a0"+(a-b));
}
var a=(prompt("Entre com valor de A para diminuir: "));
var  b=(prompt("Entre com valor de B para diminuir: "));
	sub(a,b);
//Multiplicação
function mult(c,d){
	document.write("<br>Multiplcar de C e D é:\u00a0"+(c*d));
}
var c=(prompt("Entre com valor de C para Multiplcar: "));
var d=(prompt("Entre com valor de D para Multiplcar: "));
	mult(c,d);	
//Divisão
	  function div(e,f){
	document.write("<br>Dividir de E e F é:\u00a0"+(e/f));
}
var e=(prompt("Entre com valor de e para Dividir: "));
var f=(prompt("Entre com valor de f para Dividir: "));
	div(e,f);
	
//function return	
function div(g,h) {
return g/h
}
var g=(prompt("Entre com valor de G para Dividir: "));
var h=(prompt("Entre com valor de H para Dividir: "));
document.write("<br>Dividir de G e H é:\u00a0"+div(g,h));
		   
function somar(i,j) {
return i+j
}
var i=parseInt(prompt("Entre com valor de I para somar retorno: "));
var j=parseInt(prompt("Entre com valor de J para somar retorno: "));
document.write("<br>Soma de I e J é:\u00a0"+somar(i,j));		   
		   
function sub(k,l) {
return k-l
}
var k=(prompt("Entre com valor de K para diminuir retorno: "));
var l=(prompt("Entre com valor de L para diminuir retorno: "));
document.write("<br>diminuir de K e L é:\u00a0"+sub(k,l));

function mult(m,n) {
return m*n
}
var m=(prompt("Entre com valor de M para Multiplicar retorno: "));
var n=(prompt("Entre com valor de N para Multiplicar retorno: "));
document.write("<br>multiplicar de M e N é:\u00a0"+mult(m,n));

// -->>>>>>>Condicionais<<<<<--

//Condicional IF

var idade=10;
if(idade<=12){
 document.write("<br>Criança");
}

//Entrando pelo Prompt com o valores
var idade=prompt("Entre com sua idade");
if(idade<=12){
 document.write("<br>Criança");
}
else{
	document.write("<br>Adulto");
}

//Condicional else if

var idade=prompt("Entre com sua idade");
if(idade<=12){
 document.write("<br>Criança");
}
else if (idade>12 && idade<=16){
	document.write("<br>Adolescente");
}
else {
	document.write("<br>Adulto");

}
